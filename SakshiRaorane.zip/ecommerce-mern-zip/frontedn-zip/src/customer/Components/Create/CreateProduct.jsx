import React from 'react'
import { Typography } from '@mui/material';
import { Box } from 'mdi-material-ui';
const CreateProduct = () => {
  return (
    <React.Fragment className=''>
        <Typography variant='h1'>Heding</Typography>
    </React.Fragment>
  )
}

export default CreateProduct