const mongoose = require("mongoose")

const mongoDbUrl='mongodb+srv://sakshiraorane28:LIT1wCj1wnu1sbgF@cluster0.mwktyri.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0'
const connectDb=()=>{
    return mongoose.connect(mongoDbUrl)
}

module.exports={connectDb}